#pragma once
#include <string>
using namespace std;

void cinErr(const string title);
void checkNameFile(string& nameFile);